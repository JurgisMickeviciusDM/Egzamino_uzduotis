var searchData=
[
  ['sp_5ffunkcija_0',['sp_funkcija',['../_egzaminui_8cpp.html#a448830b680b8aa951b9fe7223041cec7',1,'Sp_funkcija:&#160;Egzaminui.cpp'],['../_naudotojas_8cpp.html#a448830b680b8aa951b9fe7223041cec7',1,'Sp_funkcija:&#160;Naudotojas.cpp']]]
];
